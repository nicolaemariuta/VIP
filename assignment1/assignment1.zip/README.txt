There is only one code file: 
Assignment1 that contains all code that I have written. 
The code is split into sections for each exercise and some exercises are split into different algorithm and experiments that I have tired.
For the Gaussian derivatives and Mexican hat filtering I have the parameter sigma that I have switched for obtaining the results from the report.
The file can be run all at once but it is better to run each section sepparately to see the results for each of exercise.
I have also included some other images that I have used for experiments.